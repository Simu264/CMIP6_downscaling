# cmip6_downscaling
Change variable to 'pr','tasmax' or 'tasmin' depending upon the variable of interest
variable = 'pr'

 Specify model name in: model_name_file = 'NorESM2-LM'
